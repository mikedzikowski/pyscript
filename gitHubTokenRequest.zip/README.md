# GitHub Registry Token Tool

A tool to authenticate to Docker/OCI registries (e.g., GHES registry) using a Personal Access Token (PAT). Includes GitHub API validation similar to the registry assessment project.

## Features

- Handles WWW-Authenticate Bearer challenge (standard flow)
- Attempts to get access tokens by guessing token endpoints
- Supports both Basic auth (username:PAT) and Bearer token authentication
- GitHub API validation to verify token and scopes before registry operations
- Separate domain URL handling for GitHub API vs registry endpoints
- Works with various registry configurations

## Installation

1. Extract the zip file
2. Install dependencies: `pip3 install -r requirements.txt`

## Usage

### For GitHub Container Registry (GHCR)

```bash
python3 ghes_registry_token.py \
    --registry ghcr.io \
    --image username/package-name \
    --username YOUR_USERNAME \
    --pat YOUR_PAT \
    --validate-github \
    --verbose
```

### For GitHub Enterprise Server (GHES)

```bash
python3 ghes_registry_token.py \
    --registry docker.company.com \
    --image company/package-name \
    --username YOUR_USERNAME \
    --pat YOUR_PAT \
    --domain-url https://github.company.com/api/v3 \
    --validate-github \
    --verbose
```

### Required Arguments

- `--registry`: Registry host (e.g., `ghcr.io` for GitHub, `docker.biogen.com` for enterprise)
- `--image`: Image path (e.g., `username/package-name`)
- `--username`: Registry/GitHub username
- `--pat`: Personal Access Token (requires `read:packages` scope for registry access)

### Optional Arguments

- `--tag`: Tag to access (default: latest)
- `--action`: Scope action: pull | push | pull,push (default: pull)
- `--timeout`: HTTP timeout seconds (default: 10)
- `--verbose`: Enable verbose logging
- `--print-token`: Print the token if one is obtained
- `--domain-url`: GitHub API domain (default: https://api.github.com for GitHub.com, customize for GHES)
- `--validate-github`: Validate GitHub token via API before attempting registry auth (recommended)

## Key Differences: Registry URL vs Domain URL

Following the pattern from the registry assessment project:

- **Registry URL** (`--registry`): The Docker registry endpoint (e.g., `ghcr.io`)
- **Domain URL** (`--domain-url`): The GitHub API endpoint for token validation (e.g., `https://api.github.com`)

For **GitHub.com**: 
- Registry: `ghcr.io`
- Domain: `https://api.github.com` (default)

For **GitHub Enterprise Server**: 
- Registry: `docker.company.com` 
- Domain: `https://github.company.com/api/v3`

## Examples

GitHub.com with validation:
```bash
python3 ghes_registry_token.py \
    --registry ghcr.io \
    --image etatarevic/my-package \
    --username etatarevic \
    --pat ghp_xxxxxxxxxxxx \
    --validate-github \
    --verbose
```

GHES without validation:
```bash
python3 ghes_registry_token.py \
    --registry docker.example.com \
    --image myorg/myapp \
    --username myuser \
    --pat ghp_xxxxxxxxxxxx \
    --domain-url https://github.example.com/api/v3
```

Print token only:
```bash
python3 ghes_registry_token.py \
    --registry ghcr.io \
    --image user/repo \
    --username user \
    --pat token \
    --print-token \
    --validate-github
```

## Exit Codes

- 0: Success (Bearer token worked)
- 1: Bearer token failed but Basic auth worked  
- 2: Both Bearer token and Basic auth failed
- 3: GitHub API token validation failed (when using `--validate-github`)

## Token Requirements

For GitHub registries, your PAT needs:
- `read:packages` (required for registry access)
- Optionally `read:org`, `read:user`, `repo` for full validation