#!/usr/bin/env python3
"""
Authenticate to a Docker/OCI registry (e.g., GHES registry) using a PAT and:
  1) Handle the WWW-Authenticate Bearer challenge (standard flow).
  2) If no challenge, attempt to get an access token by guessing token endpoints,
     trying both Basic (username:PAT) and a Bearer token built from base64(username:PAT).

Usage:
  python ghes_registry_token.py \
      --registry docker.biogen.com \
      --image biogen/myapp \
      --username USERNAME \
      --pat YOUR_PAT \
      [--action pull] [--tag latest] [--verbose]
"""
import argparse
import base64
import json
import re
import sys
from typing import Dict, Optional, Tuple
import requests

DEFAULT_ACCEPT = (
    "application/vnd.oci.image.manifest.v1+json, "
    "application/vnd.docker.distribution.manifest.v2+json, "
    "application/vnd.docker.distribution.manifest.v1+json"
)

def b64(s: str) -> str:
    return base64.b64encode(s.encode("utf-8")).decode("ascii")

def probe_registry(registry: str, image: str, tag: str, timeout: float = 10.0) -> Tuple[int, Dict[str, str]]:
    """Do an unauthenticated probe to trigger 401 + WWW-Authenticate (if supported)."""
    url = f"https://{registry}/v2/{image}/manifests/{tag}"
    resp = requests.get(url, headers={"Accept": DEFAULT_ACCEPT}, timeout=timeout)
    # Collect case-insensitive headers into a plain dict
    hdrs = {k.title(): v for k, v in resp.headers.items()}
    return resp.status_code, hdrs

def parse_www_authenticate(www: str) -> Dict[str, str]:
    """
    Parse a WWW-Authenticate header for Bearer params like:
      Bearer realm="https://.../token",service="docker.biogen.com",scope="repository:ns/name:pull"
    Returns dict with keys: scheme, realm, service, scope (missing keys may be absent).
    """
    out = {"scheme": "", "realm": "", "service": "", "scope": ""}
    if not www:
        return out
    # Split off scheme
    m = re.match(r'^\s*([A-Za-z]+)\s+(.*)$', www)
    if not m:
        return out
    out["scheme"] = m.group(1)
    params = m.group(2)

    # Extract key="value" pairs
    for key in ("realm", "service", "scope"):
        mm = re.search(rf'{key}\s*=\s*"([^"]+)"', params)
        if mm:
            out[key] = mm.group(1)
    return out

def token_via_bearer_challenge(realm: str, service: str, scope: str,
                               username: str, pat: str,
                               timeout: float = 10.0, verbose: bool = False) -> Optional[str]:
    """Exchange username:PAT for a registry Bearer token using the challenge-provided realm/service/scope."""
    if not scope:
        # Construct a default scope if server didn’t provide one (rare, but safe fallback)
        # Caller should pass a best-effort scope like repository:ns/name:pull
        pass
    url = f"{realm}?service={service}"
    if scope:
        url += f"&scope={scope}"
    if verbose:
        print(f"[challenge] GET {url}")

    resp = requests.get(
        url,
        headers={"Accept": "application/json"},
        auth=(username, pat),
        timeout=timeout
    )
    if verbose:
        print(f"[challenge] status={resp.status_code} body={resp.text[:300]}...")
    if resp.ok:
        data = resp.json()
        return data.get("token") or data.get("access_token")
    return None

def guess_token_endpoints(registry: str) -> Tuple[str, ...]:
    """
    Common token endpoints some registries expose (order matters).
    We’ll try each until one returns a token-like payload.
    """
    return (
        f"https://{registry}/token",
        f"https://{registry}/oauth2/token",
        f"https://{registry}/oauth/token",
        # Some reverse proxies mount at /v2/token
        f"https://{registry}/v2/token",
    )

def try_guess_token(registry: str, scope: str, username: str, pat: str,
                    timeout: float = 10.0, verbose: bool = False) -> Optional[str]:
    """
    Attempt to fetch a token without a WWW-Authenticate challenge:
     1) Try GET with Basic auth (username:PAT).
     2) Try GET with Bearer base64(username:PAT) as requested.
    """
    endpoints = guess_token_endpoints(registry)
    basic = "Basic " + b64(f"{username}:{pat}")
    bearer_from_basic = "Bearer " + b64(f"{username}:{pat}")

    for ep in endpoints:
        for auth_header in (basic, bearer_from_basic):
            url = f"{ep}?service={registry}&scope={scope}"
            if verbose:
                print(f"[guess] GET {url}  Authorization: {auth_header.split()[0]} …")
            resp = requests.get(
                url,
                headers={
                    "Accept": "application/json",
                    "Authorization": auth_header
                },
                timeout=timeout
            )
            if verbose:
                print(f"[guess] status={resp.status_code} body={resp.text[:300]}...")
            if resp.ok:
                try:
                    data = resp.json()
                except json.JSONDecodeError:
                    continue
                token = data.get("token") or data.get("access_token")
                if token:
                    return token
    return None

def fetch_manifest_with_token(registry: str, image: str, tag: str, token: str,
                              timeout: float = 10.0, verbose: bool = False) -> bool:
    url = f"https://{registry}/v2/{image}/manifests/{tag}"
    if verbose:
        print(f"[fetch] GET {url}  (Bearer token...)")
    resp = requests.get(
        url,
        headers={
            "Accept": DEFAULT_ACCEPT,
            "Authorization": f"Bearer {token}",
        },
        timeout=timeout
    )
    if verbose:
        print(f"[fetch] status={resp.status_code}")
    return resp.ok

def fetch_manifest_with_fallbacks(registry: str, image: str, tag: str, token: str, username: str, pat: str,
                                 timeout: float = 10.0, verbose: bool = False) -> Tuple[bool, str]:
    """
    Try multiple approaches to fetch manifest:
    1. Challenge-based token (current approach)
    2. PAT directly 
    3. PAT with enhanced Accept headers
    4. Basic auth fallback
    """
    url = f"https://{registry}/v2/{image}/manifests/{tag}"
    
    # Attempt 1: Challenge-based token (current approach)
    if verbose:
        print(f"[fetch-1] Trying challenge token: GET {url}")
    resp = requests.get(
        url,
        headers={
            "Accept": DEFAULT_ACCEPT,
            "Authorization": f"Bearer {token}",
        },
        timeout=timeout
    )
    if verbose:
        print(f"[fetch-1] Challenge token status={resp.status_code}")
    if resp.ok:
        return True, "challenge-token"
    
    # Attempt 2: PAT directly
    if verbose:
        print(f"[fetch-2] Trying PAT directly: GET {url}")
    resp = requests.get(
        url,
        headers={
            "Accept": DEFAULT_ACCEPT,
            "Authorization": f"Bearer {pat}",
        },
        timeout=timeout
    )
    if verbose:
        print(f"[fetch-2] PAT direct status={resp.status_code}")
    if resp.ok:
        return True, "pat-direct"
    
    # Attempt 3: PAT with enhanced Accept headers (what podman might use)
    enhanced_accept = (
        "application/vnd.docker.distribution.manifest.v2+json, "
        "application/vnd.docker.distribution.manifest.list.v2+json, "
        "application/vnd.oci.image.manifest.v1+json, "
        "application/vnd.oci.image.index.v1+json, "
        "application/vnd.docker.distribution.manifest.v1+prettyjws, "
        "application/json, "
        "*/*"
    )
    if verbose:
        print(f"[fetch-3] Trying PAT with enhanced headers: GET {url}")
    resp = requests.get(
        url,
        headers={
            "Accept": enhanced_accept,
            "Authorization": f"Bearer {pat}",
            "User-Agent": "registry-assessment/1.0",
        },
        timeout=timeout
    )
    if verbose:
        print(f"[fetch-3] PAT enhanced status={resp.status_code}")
    if resp.ok:
        return True, "pat-enhanced"
    
    # Attempt 4: Basic auth fallback
    if verbose:
        print(f"[fetch-4] Trying Basic auth: GET {url}")
    resp = requests.get(
        url,
        headers={
            "Accept": enhanced_accept,
            "User-Agent": "registry-assessment/1.0",
        },
        auth=(username, pat),
        timeout=timeout
    )
    if verbose:
        print(f"[fetch-4] Basic auth status={resp.status_code}")
    if resp.ok:
        return True, "basic-auth"
    
    return False, "all-methods-failed"

def fetch_manifest_with_basic(registry: str, image: str, tag: str,
                              username: str, pat: str,
                              timeout: float = 10.0, verbose: bool = False) -> bool:
    """Last resort: some registries accept direct Basic auth for v2 endpoints."""
    url = f"https://{registry}/v2/{image}/manifests/{tag}"
    if verbose:
        print(f"[basic] GET {url}  (Basic username:PAT)")
    resp = requests.get(
        url,
        headers={"Accept": DEFAULT_ACCEPT},
        auth=(username, pat),
        timeout=timeout
    )
    if verbose:
        print(f"[basic] status={resp.status_code}")
    return resp.ok

def validate_github_token(domain_url: str, username: str, pat: str, timeout: float = 10.0, verbose: bool = False) -> bool:
    """Validate GitHub PAT by checking user details and scopes like the registry assessment project."""
    try:
        url = f"{domain_url}/user"
        headers = {
            "Authorization": f"Bearer {pat}",
            "Accept": "application/vnd.github.v3+json"
        }
        if verbose:
            print(f"[github-api] GET {url}")
        
        resp = requests.get(url, headers=headers, timeout=timeout)
        if verbose:
            print(f"[github-api] status={resp.status_code}")
        
        if not resp.ok:
            return False
            
        data = resp.json()
        token_username = data.get("login", "")
        scopes = resp.headers.get("X-OAuth-Scopes", "")
        
        if verbose:
            print(f"[github-api] token username: {token_username}, scopes: {scopes}")
        
        # Check username matches
        if token_username != username:
            if verbose:
                print(f"[github-api] username mismatch: expected {username}, got {token_username}")
            return False
        
        # Check required scopes for registry access
        required_scopes = ["read:packages"]
        scope_list = [s.strip() for s in scopes.split(",")]
        
        for required in required_scopes:
            has_scope = required in scope_list
            
            # Special case: write:packages implies read:packages on GitHub Enterprise Server
            if not has_scope and required == "read:packages":
                has_scope = "write:packages" in scope_list
            
            if not has_scope:
                if verbose:
                    print(f"[github-api] missing required scope: {required}")
                return False
        
        return True
        
    except Exception as e:
        if verbose:
            print(f"[github-api] validation error: {e}")
        return False

def main():
    ap = argparse.ArgumentParser(description="Fetch a registry token (or manifest) using PAT with/without WWW-Authenticate.")
    ap.add_argument("--registry", required=True, help="Registry host, e.g. ghcr.io or docker.biogen.com")
    ap.add_argument("--image", required=True, help="Image path, e.g. biogen/myapp")
    ap.add_argument("--tag", default="latest", help="Tag to access (default: latest)")
    ap.add_argument("--username", required=True, help="Registry/GitHub username")
    ap.add_argument("--pat", required=True, help="Personal Access Token (use packages scopes for registry)")
    ap.add_argument("--action", default="pull", help="Scope action: pull | push | pull,push (default: pull)")
    ap.add_argument("--timeout", type=float, default=10.0, help="HTTP timeout seconds (default: 10)")
    ap.add_argument("--verbose", action="store_true", help="Verbose logging")
    ap.add_argument("--print-token", action="store_true", help="Print the token if one is obtained")
    ap.add_argument("--domain-url", help="GitHub API domain (default: https://api.github.com for GitHub, or custom for GHES)")
    ap.add_argument("--validate-github", action="store_true", help="Validate GitHub token via API before attempting registry auth")
    args = ap.parse_args()

    scope = f"repository:{args.image}:{args.action}"
    
    # Set default domain URL for GitHub API calls
    domain_url = args.domain_url or "https://api.github.com"
    
    if args.verbose:
        print(f"[config] Registry: {args.registry}")
        print(f"[config] Image: {args.image}")
        print(f"[config] Tag: {args.tag}")
        print(f"[config] Username: {args.username}")
        print(f"[config] PAT: {'*' * (len(args.pat) - 4)}{args.pat[-4:] if len(args.pat) > 4 else '***'}")
        print(f"[config] Domain URL: {domain_url}")
        print(f"[config] Scope: {scope}")
        print(f"[config] Timeout: {args.timeout}s")
    
    # Step 0: Optional GitHub API validation (like registry assessment project)
    if args.validate_github:
        if args.verbose:
            print(f"[validation] Validating GitHub token via API at {domain_url}")
        
        is_valid = validate_github_token(domain_url, args.username, args.pat, timeout=args.timeout, verbose=args.verbose)
        if not is_valid:
            print("❌ GitHub token validation failed - check username, token, and scopes")
            sys.exit(3)
        
        if args.verbose:
            print("✅ [validation] GitHub token validation successful")

    # Step 1: Probe for Bearer challenge
    if args.verbose:
        print(f"[probe] Probing registry for authentication challenge...")
    
    status, headers = probe_registry(args.registry, args.image, args.tag, timeout=args.timeout)
    www = headers.get("Www-Authenticate", "")
    if args.verbose:
        print(f"[probe] status={status} WWW-Authenticate={www!r}")
        if status == 200:
            print("[probe] ✅ Registry allows anonymous access")
        elif status == 401:
            print("[probe] 🔐 Registry requires authentication")
        elif status == 404:
            print("[probe] ❓ Image/repository not found or not accessible")
        else:
            print(f"[probe] ❓ Unexpected status code: {status}")

    token: Optional[str] = None
    auth_method = "none"

    # If we got a Bearer challenge, do the standard flow
    parsed = parse_www_authenticate(www)
    if parsed.get("scheme", "").lower() == "bearer" and parsed.get("realm"):
        realm = parsed["realm"]
        service = parsed.get("service") or args.registry
        challenge_scope = parsed.get("scope") or scope
        if args.verbose:
            print(f"[challenge] 🎯 Bearer challenge detected:")
            print(f"[challenge]   realm={realm}")
            print(f"[challenge]   service={service}")
            print(f"[challenge]   scope={challenge_scope}")
        
        token = token_via_bearer_challenge(
            realm=realm,
            service=service,
            scope=challenge_scope,
            username=args.username,
            pat=args.pat,
            timeout=args.timeout,
            verbose=args.verbose
        )
        if token:
            auth_method = "challenge"
            if args.verbose:
                print("✅ [challenge] Successfully obtained token via Bearer challenge")

    # If no challenge or failed to get token, try "no-challenge" guesses
    if not token:
        if args.verbose:
            if parsed.get("scheme"):
                print("❌ [challenge] Bearer challenge failed, trying fallback methods...")
            else:
                print("[fallback] No Bearer challenge detected, trying guess endpoints...")
        
        token = try_guess_token(
            registry=args.registry,
            scope=scope,
            username=args.username,
            pat=args.pat,
            timeout=args.timeout,
            verbose=args.verbose
        )
        if token:
            auth_method = "guess"
            if args.verbose:
                print("✅ [fallback] Successfully obtained token via endpoint guessing")

    if token:
        if args.print_token:
            print(token)
        if args.verbose:
            print(f"[test] Testing Bearer token with multiple fallback approaches...")
        
        # Try multiple approaches to fetch the manifest
        ok, method_used = fetch_manifest_with_fallbacks(
            args.registry, args.image, args.tag, token, args.username, args.pat,
            timeout=args.timeout, verbose=args.verbose
        )
        
        result_msg = "✅ SUCCESS" if ok else "❌ FAILED"
        if ok:
            print(f"Manifest fetch: {result_msg} (auth method: {auth_method}, fetch method: {method_used})")
        else:
            print(f"Bearer manifest fetch: {result_msg} (method: {auth_method})")
        
        if args.verbose and ok:
            print(f"🎉 Authentication successful! Registry access granted via {auth_method} auth and {method_used} fetch method.")
        
        sys.exit(0 if ok else 1)

    # Final fallback: try direct Basic auth (some registries allow it)
    if args.verbose:
        print("[final] 🔄 Trying direct Basic auth to the manifest endpoint...")
    
    ok = fetch_manifest_with_basic(
        args.registry, args.image, args.tag,
        args.username, args.pat,
        timeout=args.timeout, verbose=args.verbose
    )
    
    result_msg = "✅ SUCCESS" if ok else "❌ FAILED"
    print(f"Basic manifest fetch: {result_msg}")
    
    if not ok:
        print("❌ All authentication methods failed:")
        print("   • Bearer token via challenge")
        print("   • Bearer token via endpoint guessing") 
        print("   • Direct Basic authentication")
        print("\n💡 Suggestions:")
        print("   • Verify your PAT has 'read:packages' scope")
        print("   • Check if the repository/image exists and is accessible")
        print("   • Try with --validate-github flag to verify token")
        print("   • For GitHub, ensure you're using --registry ghcr.io")
    
    # Exit non-zero if both token and basic failed
    sys.exit(0 if ok else 2)

if __name__ == "__main__":
    main()